//
//  Part3ViewController.swift
//  AudioLabSwift
//
//  Created by yinze cui on 2021/9/16.
//  Copyright © 2021 Eric Larson. All rights reserved.
//

import UIKit

class Part3ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
